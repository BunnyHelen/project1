import React from "react";
import "antd/dist/antd.css";
import { AutoComplete, Modal } from "antd";
import { CloseCircleOutlined } from "@ant-design/icons";
import "./index.css";
import internal from "stream";

interface IProps {
  titleText?: string;
  visible?: boolean;
  children?: JSX.Element;
  widthNumber?: number;
  setVisible: (isVisible: boolean) => void;
}
const MyModal = (props: IProps) => {
  const {
    children,
    titleText,
    widthNumber,
    visible,
    setVisible = () => {},
  } = props;

  return (
    <>
      <Modal
        width={widthNumber}
        closeIcon={<CloseCircleOutlined />}
        title={<div className="modal-title">{titleText}</div>}
        visible={visible}
        footer={null}
        onCancel={() => setVisible(false)}
      >
        {children}
      </Modal>
    </>
  );
};

export default MyModal;
