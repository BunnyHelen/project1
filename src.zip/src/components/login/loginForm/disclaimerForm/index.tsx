import React, { useState } from "react";
import "./index.css";

const Disclaimer = ({ handleOnLogin = () => {} }) => {
  const data = [
    {
      "Categories of Cookie Usage": "Authentication",
      Description:
        "If you're signed in to Nannydeal.com, cookies help us show you the right information and personalize your experience.",
    },
    {
      "Categories of Cookie Usage": "Security",
      Description:
        "We use cookies to enable and support our security feature, and to help us detect malicious activity and violations of you User Agreement.",
    },
    {
      "Categories of Cookie Usage": "Preferences, features, services",
      Description:
        "Cookies can tell us which language you prefer and what your communications preferences are. They can help you fill out forms on LinkedIn more easily. They also provide you with feature, insights, and customized content in conjunction with your plugins. You can learn more about plugins in our Privacy Policy.",
    },
  ];

  return (
    <div id="whole">
      <div>
        The information provided by Nanny Express Service LLC. on is for general
        public informational purpose only. We make no representation or warranty
        of any kind, express or implied, regarding the accuracy, adequacy,
        validaity, reliability, avalability or completeness of any information
        on the nannydeal.com.
      </div>
      <br />
      <div>
        Nannydeal.com is an online website for sharing home-related service
        experience. Nannydeal.com do not endorse, represent, support or
        guarentee the accuracy. completeness or reliability of any content or
        communications posted on this website. In no event shall Nannydeal.com
        be liable for any loss or damage including without limitation, indirect
        or consequential loss or damage from using this website.
      </div>
      <br />
      <h3>What are the cookies used for?</h3>
      <div>
        Cookies could be used to recognize you when you visit Nannydeal.com,
        remember your preference, and give you personailzed experience that's in
        line with your setting. Cookies also make your interactions with
        Nannydeal.com faster and more secure.
      </div>
      <br />
      <table>
        <tr>
          <th>Categories of Cookie Usage</th>
          <th>Description</th>
        </tr>
        {data.map((val, key) => {
          return (
            <tr key={key}>
              <td>{val["Categories of Cookie Usage"]}</td>
              <td>{val.Description}</td>
            </tr>
          );
        })}
      </table>
    </div>
  );
};

export default Disclaimer;
